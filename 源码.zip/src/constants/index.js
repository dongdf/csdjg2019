/*联调环境*/

// export const ENV = process.env.NODE_ENV
// export const APP_ID = 'wx8a4abd22b3ba94f6'
// export const REDIRECT_URL = 'http://test.caiheshui.com'
// export const HOST = 'http://192.168.1.210:19999/gw/' //http://test.caiheshui.com/gw/
// export const OPEN_AUTH_URL = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${APP_ID}&redirect_uri=${REDIRECT_URL}&response_type=code&scope=snsapi_userinfo&state=STATE`
// export const imAppKey='6366460695d6c714a5f02acb8ee275b9'
// export const imAppSecret='b10cba9bd271'


/*测试环境*/
// export const ENV = process.env.NODE_ENV
// export const APP_ID = 'wx8a4abd22b3ba94f6'
// export const FLODER = '/tax1.0/'
// export const DOWNZIP = 'https://chs-picture.oss-cn-beijing.aliyuncs.com/bb_model/税收健康体检采集表.zip'
// export const REDIRECT_URL = 'https://weixin.caiheshui.com'
// export const HOST = 'https://weixin.caiheshui.com/gw/' //http://test.caiheshui.com/gw/
// export const HOSTUPLOAD = 'https://weixin.caiheshui.com/zuul/gw/'
// export const OPEN_AUTH_URL = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${APP_ID}&redirect_uri=${REDIRECT_URL}&response_type=code&scope=snsapi_userinfo&state=STATE`
// export const imAppKey='6366460695d6c714a5f02acb8ee275b9'
// export const imAppSecret='b10cba9bd271'

/*测试环境*/

/*生产环境*/
export const ENV = process.env.NODE_ENV
export const APP_ID = 'wx8a4abd22b3ba94f6'
export const FLODER = '/tax1.0/'
export const DOWNZIP = 'https://chs-picture.oss-cn-beijing.aliyuncs.com/bb_model/税收健康体检采集表.zip'
export const REDIRECT_URL = 'https://wechat.caiheshui.com'
export const HOST = 'https://wechat.caiheshui.com/gw/' //http://test.caiheshui.com/gw/
export const HOSTUPLOAD = 'https://wechat.caiheshui.com/zuul/gw/'
export const OPEN_AUTH_URL = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${APP_ID}&redirect_uri=${REDIRECT_URL}&response_type=code&scope=snsapi_userinfo&state=STATE`
export const imAppKey='6366460695d6c714a5f02acb8ee275b9'
export const imAppSecret='b10cba9bd271'
/*生产环境*/

//192.168.69.114
